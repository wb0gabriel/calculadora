console.log("inicio");

var num1 = 0;
var num2 = 0;
var operator;

window.onload = function (e) {
    num1 = 0;
    num2 = 0;
    operator = "";
}


// funcoes principais
function insertTecla(e) {
    console.log("inserttecla verifica se num1 e num1 estao preenchidos se nao preenche o operadorl e tb exibe o valor digitado no resultado")
    e = e || window.event;
    var nums = e.key;
    insertMouse(nums);
}

function insertMouse(nums) {
    if (isNaN(+nums)) {
        if (num1 && num2){
            fazConta();
            console.log('resultado é  ' + num1);
        }
        if (operator != '=') {
            operator = nums;
        }
    } else {
        if (operator === "") {
            num1 = num1 * 10 + +nums;
        } else {
            num2 = num2 * 10 + +nums;
        }
    }
    teclaNums(nums);
}

function teclaNums(nums) {
    console.log("teclanums chama algumas funcoes a partir de verificacoes de if else, quando aperta numeros botoes de operacao ou botoes de limpeza tipo o esc")
    console.log(nums);
    if (nums == '1' || nums == '2' || nums == '3' || nums == '4' || nums == '5' || nums == '6' || nums == '7' || nums == '8' || nums == '9' || nums == '0' || nums == '+' || nums == '-' || nums == '*' || nums == '/') {
        exibeNums(nums)
    }

    if (nums == 'Escape') {
        clean(resultado);
    }

    if (nums == '=' || nums == '+' || nums == '-' || nums == '/' || nums == '*') {
        cleanVisor();
    }
}

function exibeNums(num) {
    var numero = document.getElementById('resultado').innerHTML;
    document.getElementById('resultado').innerHTML = numero + num;
}

document.getElementById("visor").onkeypress = function (event) {
    var Code = (event.which) ? event.which : event.keyCode;
    if (Code > 31 && (Code < 48 || Code > 57)) {
        return false;
    }
    return true;
};

function fazConta() {
    console.log ("funcao fazConta faz aS CONTINHAS")
    console.log('chegou na funcao resultado' + operator)
    console.log("numero 1 = " + num1)
    console.log("numero 2 = " + num2)
    console.log("operador = " + operator)
    var result = "";

    switch (operator) {
        case "+":
            result = +num1 + +num2;
            break;
        case "-":
            result = num1 - num2;
            break;
        case "*":
            result = num1 * num2;
            break;
        case "/":
            result = num1 / num2;
            break;
    }

    num1 = result;
    num2 = "";
    operator = "";
    document.getElementById('resultado').innerHTML = num1;
    return result;
}
//

// funcao esquisita eval
// function calcular() {
//     console.log("funcao zoada que nao deve ser usada que calcula o que ta no visor e só funciona nas teclas normais da calculadora sem ser as do teclado")
//     var resultado = document.getElementById('resultado').innerHTML;
//     if (resultado) {
//         document.getElementById('resultado').innerHTML = eval(resultado);
//     }
//     else {
//         document.getElementById('resultado').innerHTML = "Nada..."
//     }
// }


// funcoes de limpeza
function cleanResu() {
    console.log("cleanresu limpa o campo resultado")
    document.getElementById('resultado').innerHTML = "";
}

function cleanVisor() {
    console.log("clean limpa o campo visor")
    document.getElementById('visor').value = "";
}

function back() {
    console.log("back funciona igual ao backspace")
    var resultado = document.getElementById('resultado').innerHTML;
    document.getElementById('resultado').innerHTML = resultado.substring(0, resultado.length - 1);
    document.getElementById('visor').value = String(value).visor.substring(0, visor.length - 1);
}
//